/**
 * @file lv_freetype.c
 *
 */
 
/*********************
 *      INCLUDES
 *********************/
 
#include "lv_freetype.h"
 
/*********************
 *      DEFINES
 *********************/
 
/**********************
 *      TYPEDEFS
 **********************/
 
/**********************
 *  STATIC PROTOTYPES
 **********************/
static bool get_glyph_dsc_cb_nocache(const lv_font_t * font, lv_font_glyph_dsc_t * dsc_out, uint32_t unicode_letter, uint32_t unicode_letter_next);
static const uint8_t * get_glyph_bitmap_cb_nocache(const lv_font_t * font, uint32_t unicode_letter);

 
 /**********************
 *  STATIC VARIABLES
 **********************/
static FT_Library library;

static const unsigned char* ft_base_addres = NULL;
static unsigned int ft_file_size = 0;

static FT_Face ft_face  = NULL;

static lv_faces_control_t face_control;
 
/**********************
 *      MACROS
 **********************/
 
/**********************
 *   GLOBAL FUNCTIONS
 **********************/
bool lv_freetype_init(FT_UInt max_faces,const unsigned char* ft_base,unsigned int size)
{
	face_control.cnt = 0;
	face_control.num = max_faces;
	_lv_ll_init(&face_control.face_ll, sizeof(FT_Face *));

	FT_Error error = FT_Init_FreeType(&library);
	if (error) 
	{
		LV_LOG_ERROR("init freeType error(%d)", error);
		return false;
	}


	ft_base_addres = ft_base;
	ft_file_size = size;

	if(FT_New_Memory_Face(library, ft_base_addres, ft_file_size,0, &ft_face))
	{
	   LV_LOG_WARN("create face error");
	   return false;
	}

   return true;
}
 
void lv_freetype_destroy(void)
{
    FT_Done_Face(ft_face);
    FT_Done_FreeType(library);
}



 bool lv_ft_font_init(lv_font_t **font,int font_size)
{
    lv_font_fmt_ft_dsc_t * dsc = lv_mem_alloc(sizeof(lv_font_fmt_ft_dsc_t));
 
    dsc->font = lv_mem_alloc(sizeof(lv_font_t));
    if(dsc->font == NULL)
	{
        lv_mem_free(dsc);
        return false;
    }

		
    FT_Size size;
    FT_Error error = FT_New_Size(ft_face, &size);
    if (error)
	{
        goto Fail;
    }
    FT_Activate_Size(size);
    //  FT_Reference_Face(face);

    FT_Set_Pixel_Sizes(ft_face, 0, font_size);
    dsc->face = ft_face;
    dsc->size = ft_face->size;
    dsc->weight = font_size;
    dsc->style = FT_FONT_STYLE_NORMAL;
	
    dsc->font->user_data = dsc;
    dsc->font->get_glyph_dsc = get_glyph_dsc_cb_nocache;
    dsc->font->get_glyph_bitmap = get_glyph_bitmap_cb_nocache;
    dsc->font->line_height = (dsc->face->size->metrics.height >> 6);
    dsc->font->base_line = -(dsc->face->size->metrics.descender >> 6);
    dsc->font->subpx = LV_FONT_SUBPX_NONE;
    dsc->font->underline_position = dsc->face->underline_position;
    dsc->font->underline_thickness = dsc->face->underline_thickness;
    dsc->font->dsc = NULL;

    *font = dsc->font;
    return true;
 
Fail:
    lv_mem_free(dsc->font);
    lv_mem_free(dsc);
    return false;
}


 void lv_ft_font_destroy(lv_font_t* font)
{
    if (font == NULL)
	{
        return;
    }
 
    lv_font_fmt_ft_dsc_t * dsc = (lv_font_fmt_ft_dsc_t *)(font->user_data);
    if (dsc) 
	{
        FT_Done_Size(dsc->size);
        FT_Done_Face(dsc->face);

        lv_mem_free(dsc->font);
        lv_mem_free(dsc);
    }
}

 
static bool get_glyph_dsc_cb_nocache(const lv_font_t * font,  lv_font_glyph_dsc_t * dsc_out, uint32_t unicode_letter, uint32_t unicode_letter_next)
{
    LV_UNUSED(unicode_letter_next);
    if(unicode_letter < 0x20) 
	{
        dsc_out->adv_w = 0;
        dsc_out->box_h = 0;
        dsc_out->box_w = 0;
        dsc_out->ofs_x = 0;
        dsc_out->ofs_y = 0;
        dsc_out->bpp = 0;
        return true;
    }
 
    FT_Error error;
    FT_Face face;
    lv_font_fmt_ft_dsc_t * dsc = (lv_font_fmt_ft_dsc_t *)(font->user_data);
    face = dsc->face;
 
    FT_UInt glyph_index = FT_Get_Char_Index( face, unicode_letter );
 
    if (face->size != dsc->size) 
	{
        FT_Activate_Size(dsc->size);
    }
 
    error = FT_Load_Glyph(face, glyph_index, FT_LOAD_DEFAULT );
    if (error)
	{
        return false;
    }
 
    error = FT_Render_Glyph( face->glyph, FT_RENDER_MODE_NORMAL);
    if (error){
        return false;
    }
 
    dsc_out->adv_w = (face->glyph->metrics.horiAdvance >> 6);
    dsc_out->box_h = face->glyph->bitmap.rows;         /*Height of the bitmap in [px]*/
    dsc_out->box_w = face->glyph->bitmap.width;         /*Width of the bitmap in [px]*/
    dsc_out->ofs_x = face->glyph->bitmap_left;         /*X offset of the bitmap in [pf]*/
    dsc_out->ofs_y = face->glyph->bitmap_top - face->glyph->bitmap.rows;         /*Y offset of the bitmap measured from the as line*/
    dsc_out->bpp = 8;         /*Bit per pixel: 1/2/4/8*/
 
    return true;
}
 
static const uint8_t * get_glyph_bitmap_cb_nocache(const lv_font_t * font, uint32_t unicode_letter)
{
    LV_UNUSED(unicode_letter);
    lv_font_fmt_ft_dsc_t * dsc = (lv_font_fmt_ft_dsc_t *)(font->user_data);
    FT_Face face = dsc->face;
    return (const uint8_t *)(face->glyph->bitmap.buffer);
}


