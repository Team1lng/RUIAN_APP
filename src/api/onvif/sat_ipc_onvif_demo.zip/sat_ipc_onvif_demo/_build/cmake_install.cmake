# Install script for directory: /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/install")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/home/anyka/arm-anykav500-linux-uclibcgnueabi/usr/bin/arm-anykav500-linux-uclibcgnueabi-objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/base64/libbase64.a")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/md5/libmd5.a")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/sha1/libsha1.a")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/mxml-3.3.1/libmxml.a")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE STATIC_LIBRARY FILES "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/onvif/libonvif.a")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include" TYPE FILE FILES
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/include/libbase64.h"
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/md5/md5.h"
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/mxml-3.3.1/mxml-private.h"
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/mxml-3.3.1/mxml.h"
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/sha1/sha1.h"
    "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/onvif/sat_ipcamera.h"
    )
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for each subdirectory.
  include("/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/base64/cmake_install.cmake")
  include("/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/md5/cmake_install.cmake")
  include("/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/sha1/cmake_install.cmake")
  include("/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/mxml-3.3.1/cmake_install.cmake")
  include("/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/onvif/cmake_install.cmake")

endif()

if(CMAKE_INSTALL_COMPONENT)
  set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
file(WRITE "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
