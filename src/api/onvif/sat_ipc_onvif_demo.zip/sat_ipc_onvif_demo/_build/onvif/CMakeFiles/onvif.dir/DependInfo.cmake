
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/onvif/onvif.c" "onvif/CMakeFiles/onvif.dir/onvif.c.o" "gcc" "onvif/CMakeFiles/onvif.dir/onvif.c.o.d"
  "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/onvif/onvif_user_token.c" "onvif/CMakeFiles/onvif.dir/onvif_user_token.c.o" "gcc" "onvif/CMakeFiles/onvif.dir/onvif_user_token.c.o.d"
  "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/onvif/sat_ipcamera.c" "onvif/CMakeFiles/onvif.dir/sat_ipcamera.c.o" "gcc" "onvif/CMakeFiles/onvif.dir/sat_ipcamera.c.o.d"
  "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/onvif/sat_user_common.c" "onvif/CMakeFiles/onvif.dir/sat_user_common.c.o" "gcc" "onvif/CMakeFiles/onvif.dir/sat_user_common.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
