open_source/base64/CMakeFiles/base64.dir/lib/arch/avx2/codec.c.o: \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/codec.c \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/lib/gcc/arm-anykav500-linux-uclibcgnueabi/4.9.4/include/stdint.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/stdint.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/features.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/bits/uClibc_config.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/sys/cdefs.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/bits/wchar.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/bits/wordsize.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/lib/gcc/arm-anykav500-linux-uclibcgnueabi/4.9.4/include/stddef.h \
 /home/anyka/arm-anykav500-linux-uclibcgnueabi/arm-anykav500-linux-uclibcgnueabi/sysroot/usr/include/stdlib.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../../include/libbase64.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../tables/tables.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../tables/../env.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../codecs.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../../include/libbase64.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/_build/open_source/base64/config.h \
 /home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/base64/lib/arch/avx2/../../env.h
