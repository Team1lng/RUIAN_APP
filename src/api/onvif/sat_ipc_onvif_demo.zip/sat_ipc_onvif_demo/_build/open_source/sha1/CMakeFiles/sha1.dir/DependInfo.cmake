
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/xiaole/smb/work/socket-onvif/sat_ipc_onvif_demo/open_source/sha1/sha1.c" "open_source/sha1/CMakeFiles/sha1.dir/sha1.c.o" "gcc" "open_source/sha1/CMakeFiles/sha1.dir/sha1.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
