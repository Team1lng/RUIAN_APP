file(REMOVE_RECURSE
  "CMakeFiles/mxml.dir/mxml-attr.c.o"
  "CMakeFiles/mxml.dir/mxml-attr.c.o.d"
  "CMakeFiles/mxml.dir/mxml-entity.c.o"
  "CMakeFiles/mxml.dir/mxml-entity.c.o.d"
  "CMakeFiles/mxml.dir/mxml-file.c.o"
  "CMakeFiles/mxml.dir/mxml-file.c.o.d"
  "CMakeFiles/mxml.dir/mxml-get.c.o"
  "CMakeFiles/mxml.dir/mxml-get.c.o.d"
  "CMakeFiles/mxml.dir/mxml-node.c.o"
  "CMakeFiles/mxml.dir/mxml-node.c.o.d"
  "CMakeFiles/mxml.dir/mxml-private.c.o"
  "CMakeFiles/mxml.dir/mxml-private.c.o.d"
  "CMakeFiles/mxml.dir/mxml-search.c.o"
  "CMakeFiles/mxml.dir/mxml-search.c.o.d"
  "CMakeFiles/mxml.dir/mxml-string.c.o"
  "CMakeFiles/mxml.dir/mxml-string.c.o.d"
  "libmxml.a"
  "libmxml.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mxml.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
