#include "video_decode.h"
#include "ak_thread.h"
#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "unistd.h"
#include "queue.h"
#include "ak_mem.h"
#include "ak_vdec.h"
#include "string.h"
#include "leo_api.h"
#include "ring_buffer.h"
#define VIDEO_DECODE_QUEUE_MAX 25
typedef struct
{
	void* prev;
	void* next;
	char frame_type;
	unsigned char* data;
	unsigned int len;
	unsigned long long pts;
	
}video_frame_info;

static int decode_src_width = 0;
static int decode_src_height = 0;

static bool video_decode_run = false;
static bool video_decode_thread_run = false;
static bool video_decode_ready = false;
static int video_decode_handle_id = -1;

static char video_decode_type = 0; //0:h264 1:mjpeg 2:h265

static ak_mutex_t video_decode_head_mutex;
static ak_mutex_t video_decode_free_mutex;


static queue_s video_decode_queue_head;
static queue_s video_decode_queue_free;
static video_frame_info video_decode_queue_buffer[VIDEO_DECODE_QUEUE_MAX];

static ring_buffer video_decode_ring_buffer;

static video_frame_info* video_deocode_queue_node_new(char type,unsigned char* data,int size)
{
	video_frame_info* node = NULL;
	ak_thread_mutex_lock(&video_decode_free_mutex);
	if(queue_empty(&video_decode_queue_free) == 0)
	{
		node = (video_frame_info*)queue_delete_next(&video_decode_queue_free);
	}
	ak_thread_mutex_unlock(&video_decode_free_mutex);
	if(node == NULL)
	{
		return NULL;
	}

	
	if(node->data != NULL)
	{
		ring_buffer_read(&video_decode_ring_buffer, char * data, int size)
		//ak_mem_free(node->data);
	}
	node->data = ak_mem_alloc(MODULE_ID_VDEC, size);
	memcpy(node->data,data,size);
	node->len = size;
	node->pts = get_sys_ms();
	node->frame_type = type;
	return node;
}
static void video_deocode_queue_node_del(video_frame_info* node)
{
	if(node != NULL)
	{
		if(node->data != NULL)
		{
			ak_mem_free(node->data);
			node->data = NULL;
		}
		ak_thread_mutex_lock(&video_decode_free_mutex);
		queue_insert((queue_s*)node, &video_decode_queue_free);
		ak_thread_mutex_unlock(&video_decode_free_mutex);
	}
}




static void video_decode_device_open(void)
{
	struct ak_vdec_param param;
    memset(&param, 0, sizeof(struct ak_vdec_param));
    param.vdec_type = video_decode_type == 1?MJPEG_ENC_TYPE:video_decode_type == 2?HEVC_ENC_TYPE:H264_ENC_TYPE;
    param.output_type = AK_YUV420SP;
    param.sc_width = decode_src_width;
    param.sc_height = decode_src_height;
	param.stream_buf_size = 1024*1024;
	param.frame_buf_num = 2;
    ak_vdec_open(&param, &video_decode_handle_id);
	ak_vdec_clear_buff(video_decode_handle_id);

	ring_buffer_init(&video_decode_ring_buffer, 512*1024);	
}

static void video_decode_queue_delete_all(void)
{
	
	ak_thread_mutex_lock(&video_decode_head_mutex);
	while(!queue_empty (&video_decode_queue_head))
	{
		video_frame_info *h264_info = (video_frame_info *)queue_delete_next(&video_decode_queue_head);
		video_deocode_queue_node_del(h264_info);		
	}
	ring_buffer_release(&video_decode_ring_buffer);
	ak_thread_mutex_unlock(&video_decode_head_mutex);
}
static void video_decode_device_close(void)
{
	video_decode_queue_delete_all();

	if(video_decode_handle_id != -1)
	{
		ak_vdec_close(video_decode_handle_id);
		video_decode_handle_id = -1;
	}
	
}


static void video_stream_head_send(void)
{
	unsigned char head[4] = {0,0,0,1};
	int dec_len = 0;
	ak_vdec_send_stream(video_decode_handle_id, head, 4, NONBLOCK, &dec_len);	
}
static void video_data_stream_send(unsigned char* pdata,int len)
{
	int dec_len = 0;
	int read_len = len;
	int send_len = 0;
	if(video_decode_type == 0)
	{
		video_stream_head_send();
	}
	
	while(read_len > 0)
	{		
		ak_vdec_send_stream(video_decode_handle_id, &pdata[send_len], read_len, NONBLOCK, &dec_len);		
		read_len -= dec_len;
		send_len += dec_len;
	}
}



static void* video_decode_thread_task(void*arg)
{
	struct ak_vdec_frame frame = {0};
	while(1)
	{
		memset(&frame,0,sizeof(struct ak_vdec_frame));
		if(ak_vdec_get_frame(video_decode_handle_id, &frame) == 0)
		{
			video_raw_push(frame.frame_obj.data.data,0,frame.frame_obj.data.pitch_width,frame.frame_obj.data.pitch_height);//,frame.width,frame.height);
			ak_vdec_release_frame(video_decode_handle_id,  &frame);
		}
		else
		{
			int status = 0;
			ak_vdec_get_decode_finish(video_decode_handle_id, &status);
			if(status)
			{
				break;
			}
		}
		 ak_sleep_ms(5);
	}
	video_raw_release_all();
	ak_thread_exit();
	return NULL;
}




static void* video_decode_task(void* arg)
{
	video_decode_thread_run = true;

	video_decode_device_open();


	ak_pthread_t  stream_thread_id;
	ak_thread_create(&stream_thread_id, video_decode_thread_task, NULL , ANYKA_THREAD_NORMAL_STACK_SIZE, -1);

	video_decode_ready = true;
	while(video_decode_run == true)
	{
		video_frame_info *node = NULL;
		ak_thread_mutex_lock(&video_decode_head_mutex);
		if(queue_empty(&video_decode_queue_head) == 0)
		{
			node = (video_frame_info *)queue_delete_next(&video_decode_queue_head);
		}
		ak_thread_mutex_unlock(&video_decode_head_mutex);
		if(node == NULL)
		{
			ak_sleep_ms(10);
			continue;
		}
		
		if((node->data != NULL)&&(node->frame_type == video_decode_type))
		{
			video_data_stream_send(node->data,node->len);
		}
		video_deocode_queue_node_del(node);
		ak_sleep_ms(10);
	}
	
	ak_thread_mutex_lock(&video_decode_head_mutex);
	video_decode_ready = false;
	ak_thread_mutex_unlock(&video_decode_head_mutex);

	ak_vdec_end_stream(video_decode_handle_id);
	ak_thread_join(stream_thread_id);

	
	video_decode_device_close();
	video_decode_thread_run = false;

	printf("===========<<< video h264 decode finish >>>===========\n");
	ak_thread_exit();
	return NULL;
}


static bool video_decode_wait_thread_quit(void)
{
	int timeout = 300;
	while(timeout--)
	{
		if(video_decode_thread_run == false)
		{
			return true;
		}
		usleep(10*1000);
	}
	return false;
}


void video_decode_init(void)
{
	ak_thread_mutex_init(&video_decode_head_mutex, NULL);
	ak_thread_mutex_init(&video_decode_free_mutex, NULL);
	
	queue_initialize(&video_decode_queue_head);
	queue_initialize(&video_decode_queue_free);
	memset(video_decode_queue_buffer,0,sizeof(video_frame_info)*VIDEO_DECODE_QUEUE_MAX);
	for(int i = 0 ; i < VIDEO_DECODE_QUEUE_MAX ; i++)
	{
		queue_insert((queue_s *)&video_decode_queue_buffer[i], &video_decode_queue_free);
	}
}

bool video_decode_open(char type,int src_width,int src_height)
{
	if(video_decode_run == true)
	{
		printf("video decode open after \n");
		return false;
	}

	if( video_decode_wait_thread_quit() == false)
	{
		printf("video decode thread wait error \n");
		return false;
	}

	decode_src_width = src_width;
	decode_src_height = src_height;
	video_decode_type = type;
	
	ak_pthread_t video_decode_thread = 0;
	video_decode_run = true;
	ak_thread_create(&video_decode_thread, video_decode_task , NULL , ANYKA_THREAD_NORMAL_STACK_SIZE , -1);
	ak_thread_detach(video_decode_thread);
	return true;
}


bool video_decode_close(void)
{
	if(video_decode_run == false)
	{
		return false;
	}
	ak_thread_mutex_lock(&video_decode_head_mutex);
	video_decode_run = false;
	ak_thread_mutex_unlock(&video_decode_head_mutex);
	return true;
}



bool video_decode_push(char type,unsigned char* data ,int len)
{
	ak_thread_mutex_lock(&video_decode_head_mutex);
	if(video_decode_ready == false)
	{	
		ak_thread_mutex_unlock(&video_decode_head_mutex);
		return false;
	}


	video_frame_info* node = video_deocode_queue_node_new(type,data,len);
	if(node != NULL)
	{
		queue_insert((queue_s *)node, &video_decode_queue_head);
	}
	ak_thread_mutex_unlock(&video_decode_head_mutex);

	return true;
}

